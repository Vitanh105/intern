package com.keycloak_api_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakApiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
