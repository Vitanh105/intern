package vanh.demo15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo15ApplicationTests {

    @Test
    void contextLoads() {
    }

}
